# BW Fancy Keyboard (Android Studio project)

A starter Android Input Method Editor (IME) with a **Fancy Styles** button that opens a style panel. It includes Monospace, Banana, Table Chair, Without Vowels, Double Letter, Alternative, Reverse Alternative, Reverse Text, and Dot Style.

## Open and build
1. Install Android Studio (current stable) and Android SDK Platform 35.
2. Open this `BWFancyKeyboard` folder in Android Studio and let Gradle sync.
3. Build > Build Bundle(s) / APK(s) > Build APK(s).
4. Install the generated APK on your Android phone.
5. On the phone, go to Settings > System/Additional settings > Keyboard & input method > Manage keyboards, enable **BW Fancy Keyboard**, then choose it as the current keyboard.

## Use
Type in any text field. Tap **Fancy Styles**, then select a style. If text is selected, the style is applied to the selection; otherwise it converts the last word before the cursor.

## Notes
- This is source project code, not a precompiled APK.
- Android settings labels differ by device manufacturer.
- Review the styles and test on your target Android version before distributing.
